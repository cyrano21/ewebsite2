import React from 'react';
import { Breadcrumb } from 'react-bootstrap';
import Link from 'next/link';

interface PageBreadcrumbProps {
  items: Array<{
    label: string;
    href?: string;
    active?: boolean;
  }>;
  className?: string;
  [key: string]: any;
}

const PageBreadcrumb: React.FC<PageBreadcrumbProps> = ({ items, className = '', ...rest }) => {
  if (!items || items.length === 0) {
    return null;
  }

  return (
    <Breadcrumb className={`mb-0 ${className}`} {...rest}>
      {items.map((item, index) => (
        <Breadcrumb.Item 
          key={index} 
          active={item.active}
          linkAs={item.href && !item.active ? 'span' : undefined}
        >
          {item.href && !item.active ? (
            <Link href={item.href} passHref legacyBehavior>
              <a>{item.label}</a>
            </Link>
          ) : (
            item.label
          )}
        </Breadcrumb.Item>
      ))}
    </Breadcrumb>
  );
};

export default PageBreadcrumb;