// Ce fichier est un placeholder pour une image
// Dans un projet réel, vous devriez utiliser une vraie image
// Cette solution temporaire permet de résoudre l'erreur de build

// Création d'une image de base 64 vide
const emptyImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

export default emptyImage;