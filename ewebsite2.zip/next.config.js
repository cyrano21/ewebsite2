/** @type {import('next').NextConfig} */
const path = require('path');

const nextConfig = {
  eslint: { 
    ignoreDuringBuilds: true 
  },
  typescript: { 
    ignoreBuildErrors: true 
  },
  images: {
    domains: ['localhost', 'res.cloudinary.com'],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
  // Configuration supplémentaire pour les styles
  sassOptions: {
    includePaths: ['./styles'],
  },
  // Optimiser la gestion des assets statiques en production
  assetPrefix: process.env.NODE_ENV === 'production' ? process.env.NEXT_PUBLIC_SITE_URL : '',
  
  // Désactiver le mode strict pour éviter les rechargements excessifs
  reactStrictMode: false,
  
  // Configuration webpack simplifiée et sécurisée
  webpack: (config, { dev, isServer }) => {
    // Éviter l'importation directe des assets dans les fichiers CSS
    const rules = config.module.rules.find((rule) => typeof rule.oneOf === 'object')?.oneOf || [];
    
    // Ajouter une règle spécifique pour les fichiers CSS
    rules.forEach((rule) => {
      if (rule.test && rule.test.test && (rule.test.test('file.css') || rule.test.test('file.scss'))) {
        if (rule.use && Array.isArray(rule.use)) {
          // Modifier les options du css-loader
          rule.use.forEach((loader) => {
            if (loader.loader && loader.loader.includes('css-loader') && loader.options) {
              // Désactiver complètement la résolution des URL pour éviter les problèmes
              loader.options.url = false;
              loader.options.import = false;
            }
          });
        }
      }
    });
    
    // En développement, optimiser la configuration mais sans manipuler entry
    // pour éviter les boucles infinies
    if (dev && !isServer) {
      // Réduire la verbosité des logs webpack
      config.infrastructureLogging = {
        level: 'error',
      };
      
      // Supprimer les plugins HMR problématiques
      config.plugins = config.plugins.filter(plugin => {
        const name = plugin.constructor.name;
        return !name.includes('HotModuleReplacement') && !name.includes('ReactRefreshPlugin');
      });
    }
    
    return config;
  },
  
  // Options de développement plus stables
  onDemandEntries: {
    // Réduire le polling qui peut causer des problèmes
    maxInactiveAge: 60 * 60 * 1000, // 1 heure
    pagesBufferLength: 5,
  },
};

module.exports = nextConfig;
