// no-hmr.js - Script pour démarrer Next.js sans HMR
// Ce script remplace la configuration HMR problématique en la désactivant complètement
// Et ajoute une gestion améliorée de la connexion MongoDB

const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');
const mongoose = require('mongoose');

// Configuration de développement sans HMR
const dev = process.env.NODE_ENV !== 'production';
const hostname = 'localhost';
const port = parseInt(process.env.PORT || '4000', 10);

// Initialiser l'application Next.js avec HMR explicitement désactivé
const app = next({ 
  dev, 
  hostname, 
  port,
  conf: {
    // Surcharger la configuration pour désactiver HMR
    webpack: (config, { isServer }) => {
      if (!isServer) {
        // Supprimer les plugins HMR de webpack
        config.plugins = config.plugins.filter(plugin => {
          const name = plugin.constructor.name;
          return !name.includes('HotModuleReplacement') && !name.includes('ReactRefresh');
        });
      }
      return config;
    },
    // Désactiver explicitement le rechargement à chaud
    webpackDevMiddleware: (config) => {
      config.watchOptions = {
        ignored: ['**/.git/**', '**/node_modules/**', '**/.next/**'],
        aggregateTimeout: 300,
        poll: false,
      };
      // Désactiver le hot reload
      config.hot = false;
      return config;
    },
  },
});

// Amélioration de la gestion de MongoDB
// Cette fonction configure MongoDB avec des options de reconnexion robustes
async function setupMongoDB() {
  try {
    // Récupérer l'URL de connexion à partir des variables d'environnement ou utiliser une URL par défaut
    const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/ecommerce-website';
    
    // Configuration améliorée de mongoose pour plus de stabilité
    const mongooseOptions = {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
      // Configuration critique pour éviter les déconnexions
      // Augmenter ces timeouts pour éviter les déconnexions pendant le développement
      heartbeatFrequencyMS: 30000,
      maxPoolSize: 10,
      minPoolSize: 5,
      connectTimeoutMS: 60000,
      // Active la gestion automatique des reconnexions
      autoReconnect: true,
      reconnectTries: Number.MAX_VALUE,
      reconnectInterval: 1000,
      // Intercepter les déconnexions
      family: 4 // Force IPv4
    };

    // Listeners pour surveiller l'état de la connexion
    mongoose.connection.on('connecting', () => {
      console.log('🔄 MongoDB: Tentative de connexion...');
    });
    
    mongoose.connection.on('connected', () => {
      console.log('✅ MongoDB: Connexion établie avec succès');
    });
    
    mongoose.connection.on('disconnected', () => {
      console.log('❌ MongoDB: Déconnecté - Tentative automatique de reconnexion');
    });
    
    mongoose.connection.on('reconnected', () => {
      console.log('🔄 MongoDB: Reconnecté avec succès');
    });
    
    mongoose.connection.on('error', (err) => {
      console.error('🔥 MongoDB: Erreur de connexion', err);
    });

    // Patching de mongoose pour rendre la connexion plus stable
    // Patch qui évite les erreurs "topology destroyed" en cas de déconnexion
    const originalConnect = mongoose.connect;
    mongoose.connect = async function(uri, options) {
      console.log('🛡️ MongoDB: Utilisation du connecteur renforcé');
      return originalConnect.call(this, uri, {
        ...mongooseOptions,
        ...options
      });
    };

    await mongoose.connect(MONGODB_URI);
    return true;
  } catch (error) {
    console.error('❌ Erreur lors de la configuration de MongoDB:', error);
    return false;
  }
}

async function startServer() {
  try {
    // Configurer MongoDB avant de démarrer Next.js
    console.log('🛡️ Configuration renforcée de MongoDB...');
    await setupMongoDB();
    
    // Préparer Next.js
    console.log('🚀 Initialisation de Next.js sans HMR...');
    await app.prepare();

    createServer(async (req, res) => {
      try {
        const parsedUrl = parse(req.url, true);
        await app.getRequestHandler()(req, res, parsedUrl);
      } catch (err) {
        console.error('Erreur lors du traitement de la requête:', err);
        res.statusCode = 500;
        res.end('Erreur interne du serveur');
      }
    }).listen(port, (err) => {
      if (err) throw err;
      console.log(`
====================================================
🔒 Mode stable: Next.js démarré SANS HMR
====================================================
📱 Local:        http://localhost:${port}
🌐 Sur le réseau: http://${hostname}:${port}
====================================================
💡 Pour voir vos modifications, rechargez manuellement la page
🛡️ Connexion MongoDB renforcée et stabilisée
⚠️ Le rechargement à chaud est intentionnellement désactivé
   pour éviter les problèmes de déconnexion MongoDB
====================================================
      `);
    });
  } catch (error) {
    console.error('Erreur lors du démarrage du serveur:', error);
    process.exit(1);
  }
}

// Intercepter les erreurs non gérées pour éviter les crashs
process.on('uncaughtException', (err) => {
  console.error('❌ Erreur non gérée:', err);
  // Ne pas quitter le processus, simplement logger l'erreur
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Promesse rejetée non gérée:', reason);
  // Ne pas quitter le processus, simplement logger l'erreur
});

console.log('🚀 Démarrage du serveur Next.js en mode stable sans HMR');
startServer();